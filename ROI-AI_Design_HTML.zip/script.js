(() => {
  'use strict';
  const $ = (selector) => document.querySelector(selector);
  const root = document.documentElement;
  const isMobile = () => window.matchMedia('(max-width: 900px)').matches;
  const openContents = $('#open-contents');
  const closeContents = $('#close-contents');
  const scrim = $('#scrim');
  function setContents(open) {
    $('#contents').inert = !open;
    if (isMobile()) {
      document.body.classList.toggle('sidebar-open', open);
      scrim.hidden = !open;
      openContents.setAttribute('aria-expanded', String(open));
      if (open) closeContents.focus();
    } else {
      document.body.classList.toggle('sidebar-collapsed', !open);
      openContents.setAttribute('aria-expanded', String(open));
    }
  }
  openContents.addEventListener('click', () => setContents(true));
  closeContents.addEventListener('click', () => { setContents(false); openContents.focus(); });
  scrim.addEventListener('click', () => { setContents(false); openContents.focus(); });
  document.querySelectorAll('.sidebar a').forEach((a) => a.addEventListener('click', () => { if (isMobile()) setContents(false); }));
  const media = window.matchMedia('(max-width: 900px)');
  media.addEventListener('change', () => { document.body.classList.remove('sidebar-open', 'sidebar-collapsed'); scrim.hidden = true; setContents(!isMobile()); });
  setContents(!isMobile());
  $('#print-page').addEventListener('click', () => window.print());
  const settings = $('#reading-settings');
  function setSettings(open) { settings.hidden = !open; $('#open-settings').setAttribute('aria-expanded', String(open)); if (open) $('#font-size').focus(); }
  $('#open-settings').addEventListener('click', () => setSettings(settings.hidden));
  $('#close-settings').addEventListener('click', () => { setSettings(false); $('#open-settings').focus(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') { const hadSettings = !settings.hidden; const hadContents = document.body.classList.contains('sidebar-open'); setSettings(false); if (hadSettings) $('#open-settings').focus(); if (hadContents) { setContents(false); openContents.focus(); } } });
  $('#font-size').addEventListener('change', (event) => root.style.setProperty('--reading-size', `${event.target.value}px`));
  $('#color-theme').addEventListener('change', (event) => { document.body.dataset.theme = event.target.value; });
  $('#wide-layout').addEventListener('change', (event) => document.body.classList.toggle('wide', event.target.checked));
  document.querySelectorAll('.copy-button').forEach((button) => {
    button.addEventListener('click', async () => {
      const value = button.parentElement.querySelector('code').textContent;
      try {
        await navigator.clipboard.writeText(value);
        button.textContent = 'Copied';
        $('#copy-status').textContent = 'Code copied to clipboard.';
        window.setTimeout(() => { button.textContent = 'Copy'; }, 1800);
      } catch {
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(button.parentElement.querySelector('code'));
        selection.removeAllRanges(); selection.addRange(range);
        button.textContent = 'Select & copy';
        $('#copy-status').textContent = 'Code selected. Use your keyboard shortcut to copy.';
      }
    });
  });
  const tocLinks = [...document.querySelectorAll('.toc a')];
  const headings = [...document.querySelectorAll('main h2[id], main h3[id]')];
  let scrollQueued = false;
  function updateActiveHeading() {
    scrollQueued = false;
    const boundary = isMobile() ? 100 : 75;
    let current = headings[0];
    for (const heading of headings) { if (heading.getBoundingClientRect().top <= boundary) current = heading; else break; }
    for (const link of tocLinks) {
      if (link.hash === `#${current.id}`) link.setAttribute('aria-current', 'location'); else link.removeAttribute('aria-current');
    }
  }
  window.addEventListener('scroll', () => { if (!scrollQueued) { scrollQueued = true; window.requestAnimationFrame(updateActiveHeading); } }, {passive:true});
  updateActiveHeading();
  const policy = $('#toy-policy');
  if (!policy) return;
  const nextButton = $('#toy-next');
  const history = $('#toy-history');
  let rows = [];
  function renderToy() {
    const count = rows.length;
    let benefit = 0, cost = 0;
    history.replaceChildren();
    if (!count) {
      const row = document.createElement('tr'); const cell = document.createElement('td');
      cell.colSpan = 6; cell.className = 'empty-row'; cell.textContent = 'Feedback appears after a period ends.';
      row.append(cell); history.append(row);
    }
    for (const data of rows) {
      benefit += data.benefit; cost += data.cost;
      const row = document.createElement('tr');
      for (const value of [data.period, data.state, data.action, data.benefit, data.cost, data.next]) { const cell = document.createElement('td'); cell.textContent = String(value); row.append(cell); }
      history.append(row);
    }
    const roi = cost > 0 ? `${Math.round((benefit - cost) / cost * 1000) / 10}%` : '—';
    $('#toy-totals').textContent = `Observed totals: benefit ${benefit} · cost ${cost} · net benefit ${benefit - cost} · ROI ${roi}`;
    $('#toy-status').textContent = count === 0 ? 'Before period 1 · State: Low usage · No outcome observed yet.' : count === 1 ? `Period 1 complete · Next state: ${rows[0].next} · Period 2 feedback is still hidden.` : `Both periods complete · Cumulative net benefit: ${benefit - cost} · Cumulative ROI: ${roi}.`;
    nextButton.textContent = count === 0 ? 'Reveal period 1 feedback' : count === 1 ? 'Reveal period 2 feedback' : 'Both periods complete';
    nextButton.disabled = count === 2;
    policy.disabled = count > 0;
  }
  nextButton.addEventListener('click', () => {
    if (rows.length >= 2) return;
    const trainFirst = policy.value === 'train';
    const second = rows.length === 1;
    rows.push(second ? {period:2,state:trainFirst?'High usage':'Low usage',action:'Keep current plan',benefit:trainFirst?15:5,cost:1,next:trainFirst?'High usage':'Low usage'} : {period:1,state:'Low usage',action:trainFirst?'Add training':'Keep current plan',benefit:trainFirst?1:5,cost:trainFirst?3:1,next:trainFirst?'High usage':'Low usage'});
    renderToy();
  });
  $('#toy-reset').addEventListener('click', () => { rows = []; renderToy(); policy.focus(); });
  policy.addEventListener('change', () => { rows = []; renderToy(); });
  renderToy();
})();
